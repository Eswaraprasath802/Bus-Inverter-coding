read_liberty "/home/eswaraprasath/Developer/vlsi/build/tools/NangateOpenCellLibrary_typical.lib"
read_verilog "/home/eswaraprasath/Developer/vlsi/build/measurements/seg4/mapped.v"
link_design segmented_bus_invert_encoder
create_clock -name bus_clk -period 10 [get_ports clk]
set inputs [get_ports {data_in* reset}]
set_input_delay -max 1 -clock bus_clk $inputs
set_input_delay -min 0 -clock bus_clk $inputs
set_input_transition 0.1 $inputs
set_output_delay -max 1 -clock bus_clk [all_outputs]
set_output_delay -min 0 -clock bus_clk [all_outputs]
set_clock_uncertainty 0.1 [get_clocks bus_clk]
set_clock_transition 0.1 [get_clocks bus_clk]
set_load 20 [all_outputs]

check_setup -verbose
report_checks -path_delay max -group_path_count 5 -digits 6
report_check_types -max_slew -max_capacitance -violators
set max_delay 0.0
foreach path [find_timing_paths -from $inputs -path_delay max -group_path_count 1000] {
    set endpoint [lindex [get_property $path points] end]
    set delay [expr {[get_property $endpoint arrival] - 1.0}]
    set max_delay [expr {max($max_delay, $delay)}]
}
foreach path [find_timing_paths -from [all_registers -clock_pins] -path_delay max -group_path_count 1000] {
    set endpoint [lindex [get_property $path points] end]
    set max_delay [expr {max($max_delay, [get_property $endpoint arrival])}]
}
puts "MAX_CELL_PATH_NS $max_delay"
report_worst_slack -max -digits 6
exit
