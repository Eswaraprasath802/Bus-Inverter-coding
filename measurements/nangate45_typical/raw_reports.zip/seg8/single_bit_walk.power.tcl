read_liberty "/home/eswaraprasath/Developer/vlsi/build/tools/NangateOpenCellLibrary_typical.lib"
read_verilog "/home/eswaraprasath/Developer/vlsi/build/measurements/seg8/mapped.v"
link_design segmented_bus_invert_encoder
create_clock -name bus_clk -period 10 [get_ports clk]
set inputs [get_ports {data_in* reset}]
set_input_delay -max 1 -clock bus_clk $inputs
set_input_delay -min 0 -clock bus_clk $inputs
set_input_transition 0.1 $inputs
set_output_delay -max 1 -clock bus_clk [all_outputs]
set_output_delay -min 0 -clock bus_clk [all_outputs]
set_clock_uncertainty 0.1 [get_clocks bus_clk]
set_clock_transition 0.1 [get_clocks bus_clk]
set_load 20 [all_outputs]
read_vcd -scope tb_mapped/dut "/home/eswaraprasath/Developer/vlsi/build/measurements/seg8/single_bit_walk.vcd"
report_activity_annotation -report_unannotated
report_power -digits 9
exit
